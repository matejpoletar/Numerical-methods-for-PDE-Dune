#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <stdexcept>

#include <dune/common/fvector.hh>

#include <dune/grid/common/mcmgmapper.hh>
#include <dune/grid/io/file/vtk/vtkwriter.hh>

// Za YaspGrid
#include <bitset>
#include <array>
#include <dune/grid/yaspgrid.hh>         // Koristimo YaspGrid

#include "elementdata.hh"
//#include "functors.hh"

// Funkcija koju prikazujemo
double f(Dune::FieldVector<double,2> const & x){
    return x[0]*x[0]+x[1]*x[1];
}

std::vector<double> normala(Dune::FieldVector<double,2> const & x){
    //double norma = std::sqrt (1 + 4 * x[0] * x[0] + 4 *x[1] * x[1]);
    std::vector<double> y{2};
    y[0] = -2*x[0];
    y[1] = -2*x[1];
    return y;
}

int main(int argc, char **argv)
{
  Dune::MPIHelper::instance(argc, argv);

  // Broj profinjenja mreže
  int refSteps = 4 ;
  // Argument komandne linije može biti broj profinjenja mreže
  if (argc > 1)
    {
      refSteps = std::atoi(argv[1]);  // atoi -> konvertira string u broj
    }
  const int dim = 2;

   typedef Dune::YaspGrid<dim> GridType;
   typedef GridType::LeafGridView GridView;
    Dune::FieldVector<GridType::ctype,dim> L(1.0);             // Duljina stranice
    std::array<int,dim>                    s={1,1};          // broj ćelija po stranici
    std::bitset<dim>                       periodic(false);    // periodičnost u svim smjerovima
    int overlap = 0;                                           // preklapanje za paralelni grid
    GridType grid(L, s, periodic, overlap); // serijska mreža
    GridView leafView = grid.leafGridView();

  std::string filename = "data";
  // Profini mrežu
  grid.globalRefine(refSteps);
  // Vektor koeficijenata
  std::vector<double> coeff;
  std::vector<double> coeff2;

  // Izračunaj coeff
  elementdata(leafView, f, normala, coeff, coeff2);

  // Ispisivanje podataka u VTK datoteku.
  Dune::VTKWriter<GridView> vtkwriter(leafView);
  // Imamo metode addCellData i addVertexData za dodavanje podataka vezanih uz
  // elemente odnosno vrhove. "data" je ime podatka.
  vtkwriter.addVertexData(coeff, "fja");
  vtkwriter.addVertexData(coeff2, "normala", 2);
  vtkwriter.write("vertex_" + filename + "_Zadatak1", Dune::VTK::OutputType::ascii);

  return 0;
}

