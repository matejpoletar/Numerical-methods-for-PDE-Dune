#include <dune/grid/common/mcmgmapper.hh>
#include <vector>
// Ova funkcija uzima grid i funkciju zadanu kao funkcijski objekt te formira vektor
// coeff koji se sastoji od vrijednosti funkcije u centrima elemenata.
// Na primjer, ako je x_i centar elementa K_i, onda je
//                   coeff[i] = f(x_i).
//
// LGV = LeafGridView
// F = Funkcijski objekt
// G = normala (gradijent)
//iteracija po vrhovima
template<class LGV, class F,class G>
void elementdata (const LGV& gridView, const F& f,const G& normala, std::vector<double> & coeff,std::vector<double> &coeff2)
{
    const int dim = LGV::dimension;
    assert(dim == 2);
    auto const &indexSet = gridView.indexSet();

    coeff.resize(indexSet.size(dim));
    coeff2.resize(dim*indexSet.size(dim));
  // Iteriramo kroz sve elemente mreže
  for (auto const & vertex :vertices(gridView))
        {
          const auto & geo = vertex.geometry();
          // Centar elementa
          auto global = geo.center();
          // Smjesti vrijednost funkcije u centru elementa na odgovarajuće mjesto u vektor.
          coeff[indexSet.index(vertex)] = f(global);
          std::vector <double> gradijent;
          gradijent = normala(global);
          for(unsigned int i=0; i<dim; ++i)
               coeff2[dim*indexSet.index(vertex)+i] = gradijent[i];

        }
}
