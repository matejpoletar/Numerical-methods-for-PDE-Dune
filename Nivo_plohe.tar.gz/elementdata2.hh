#include <dune/grid/common/mcmgmapper.hh>
#include <vector>
// Ova funkcija uzima grid i funkciju zadanu kao funkcijski objekt te formira vektor
// coeff koji se sastoji od vrijednosti funkcije u centrima elemenata.
// Na primjer, ako je x_i centar elementa K_i, onda je
//                   coeff[i] = f(x_i).
//
// LGV = LeafGridView
// F = Funkcijski objekt
// G = normala (gradijent)
//iteracija po vrhovima
template<class LGV, class F>
void elementdata2 (const LGV& gridView, const F& f, std::vector<double> & coeff, double i)
{
    const int dim = LGV::dimension;
    assert(dim == 2);
    auto const &indexSet = gridView.indexSet();

    coeff.resize(indexSet.size(dim));
  // Iteriramo kroz sve elemente mreže
  for (auto const & vertex :vertices(gridView))
        {
          const auto & geo = vertex.geometry();
          // Centar elementa
          auto global = geo.center();
          // Smjesti vrijednost funkcije u centru elementa na odgovarajuće mjesto u vektor.
          coeff[indexSet.index(vertex)] = f(global) - i;

        }
}
