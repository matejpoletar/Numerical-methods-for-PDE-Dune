//NIVO PLOHE
//prikazujemo 4 nivo plohe funkcije F(x,y,z)= z- f(x,y) gdje je f(x,y) = sin(x) + sin(y)

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <stdexcept>

#include <dune/common/fvector.hh>

#include <dune/grid/common/mcmgmapper.hh>
#include <dune/grid/io/file/vtk/vtkwriter.hh>

// Za YaspGrid
#include <bitset>
#include <array>
#include <dune/grid/yaspgrid.hh>         // Koristimo YaspGrid

#include "elementdata2.hh"
//#include "functors.hh"

// Funkcija koju prikazujemo f(x,y)
double f(Dune::FieldVector<double,2> const & x){
    return std::sin (x[0]) + std::sin(x[1]);
}

int main(int argc, char **argv)
{
  Dune::MPIHelper::instance(argc, argv);

  // Broj profinjenja mreže
  int refSteps = 4 ;
  // Argument komandne linije može biti broj profinjenja mreže
  if (argc > 1)
    {
      refSteps = std::atoi(argv[1]);  // atoi -> konvertira string u broj
    }
  const int dim = 2;

   typedef Dune::YaspGrid<dim> GridType;
   typedef GridType::LeafGridView GridView;
    Dune::FieldVector<GridType::ctype,dim> L(6.28);             // Duljina stranice
    std::array<int,dim>                    s={1,1};          // broj ćelija po stranici
    std::bitset<dim>                       periodic(false);    // periodičnost u svim smjerovima
    int overlap = 0;                                           // preklapanje za paralelni grid
    GridType grid(L, s, periodic, overlap); // serijska mreža
    GridView leafView = grid.leafGridView();

  std::string filename = "data";
  // Profini mrežu
  grid.globalRefine(refSteps);
  // Vektor koeficijenata
  std::vector<double> coeff, coeff2, coeff3, coeff4;

  // Izračunaj vektor coeff za 4 nivo plohe
  //cetvrti parametar je z u z = f(x,y)
  elementdata2(leafView, f, coeff, 0);
  elementdata2(leafView, f, coeff2, -2);
  elementdata2(leafView, f, coeff3, 1.5);
  elementdata2(leafView, f, coeff4, 4);


  // Ispisivanje podataka u VTK datoteku.
  Dune::VTKWriter<GridView> vtkwriter(leafView);
  // Imamo metode addCellData i addVertexData za dodavanje podataka vezanih uz
  // elemente odnosno vrhove. "data" je ime podatka.
  vtkwriter.addVertexData(coeff, "prva nivo ploha");
  vtkwriter.addVertexData(coeff2, "druga nivo ploha");
  vtkwriter.addVertexData(coeff3, "treca nivo ploha");
  vtkwriter.addVertexData(coeff4, "cetvrta nivo ploha");
  vtkwriter.write("vertex_" + filename +"_nivoPlohe", Dune::VTK::OutputType::ascii);

  return 0;
}

